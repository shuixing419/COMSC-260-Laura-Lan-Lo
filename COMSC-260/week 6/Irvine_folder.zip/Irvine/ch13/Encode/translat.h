// translat.h

void TranslateBuffer( char * buf, unsigned count, 
                      unsigned char eChar );

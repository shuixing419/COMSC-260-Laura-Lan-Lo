(readme.txt) HelloNew program, Chapter 10

Use the makeHello16.bat found in the current directory 
to assemble and link the HelloNew.asm program for 16-bit Real mode.
